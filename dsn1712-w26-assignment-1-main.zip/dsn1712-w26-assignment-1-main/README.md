# Assignment #1

## Assignment details

Refer to assignment on Brightspace for full instructions, marking scheme and how to submit.